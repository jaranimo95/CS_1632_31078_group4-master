README

To build the tests, but them into the same directories as their corresponding files, so all the 
	ship tests go in the ships folder and all the board/coordinate tests go in the board folder.

	To compile,
		javac .;(directory of hamcrest jar);(directory of junit jar); org.junit.runner.JUnitCore (path to file)/filename.java

	To run,
		java (same as above) package.of.filename (not literally this, but just copy whatever package it's included in from the source code itself. it'll be on the first line)


I never was able to get pexpect to work on my computer, but I still attempted to write a program
	with legal syntax despite it, and, as such, I have not done any testing of it whatsoever outside
	of looking at it/whiteboarding/rubber duck debugging, so it might be fruitless to execute it in
	its current state. I heavily commented it regardless to help you understand the gist of what I
	was attempting to do.


Thank you and I hope your grading process goes better than my experience with this project!
