package edu.pitt.battleshipgame.common.board;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

public class CoordinateTest {

	@Test
	public void setCoordinatesTest() {
		
	}
	
}